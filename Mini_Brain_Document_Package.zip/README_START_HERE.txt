MINI-BRAIN WRITING PACKAGE — 15 November 2026

START HERE
1. Read Mini_Brain_Research_Draft.pdf.
2. Edit Mini_Brain_Research_Draft.docx if desired.
3. Follow Mini_Brain_Closure_Checklist.pdf only if completing validation.

Included: manuscript and checklist in PDF, editable Word, and Markdown.
Not included: experimental CSVs, raw simulation archives, executed validation, or verified commercial benchmarks.

Status: writing draft based on supplied conversation, not a validated final paper.
Important corrections: no claim of completed v7 validation; no preregistration claim; no proof of memory or consciousness; no verified 3 dB D4 gain claim.
These files were generated locally for download, not uploaded to the TOLBIT repository.
