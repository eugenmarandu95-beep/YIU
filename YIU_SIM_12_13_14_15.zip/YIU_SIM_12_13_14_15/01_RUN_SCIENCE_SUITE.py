"""YIU science pilot 12-15. Python 3.10+, numpy. No API or LLM required."""
import argparse,csv,hashlib,json,platform,sys
from pathlib import Path
import numpy as np
SEEDS=list(range(9001,9031))
def sha(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rows=[];raw={'config':{'seeds':SEEDS,'S12':'pipeline corruption and independent recomputation','S13':'cross-domain theory transfer with held-out mechanism','S14':'computational probes: integration, broadcast, prediction; not consciousness claims','S15':'four-agent coordination with shared blackboard, permissions, and duplicate prevention'},'trials':[]}
    for seed in SEEDS:
        rng=np.random.default_rng(seed)
        # S12 reproducibility
        n=200;x=rng.normal(size=n);true_a=1.3;y=1.3*x+rng.normal(0,.4,n)
        def fit(xx,yy):return float(np.linalg.lstsq(np.column_stack([np.ones(len(xx)),xx]),yy,rcond=None)[0][1])
        original={'slope':fit(x,y),'data_hash':sha({'x':x.tolist(),'y':y.tolist()}),'code_hash':'fixed_v1'}
        corrupt=x.copy();corrupt[7]+=25.0
        variants={'original':(x,y),'corrupted_data':(corrupt,y)}
        for name,(xx,yy) in variants.items():
            slope=fit(xx,yy);recomputed=fit(x,y)
            detected=int(abs(slope-recomputed)>1e-6)
            rows.extend([{'sim':'12','seed':seed,'method':name,'metric':'slope','value':slope},{'sim':'12','seed':seed,'method':name,'metric':'corruption_detected','value':detected},{'sim':'12','seed':seed,'method':name,'metric':'recovery_error','value':abs(slope-recomputed)}])
        raw['trials'].append({'sim':'12','seed':seed,'original':original,'corrupted_data':{'x':corrupt.tolist(),'y':y.tolist()},'recomputed_slope':recomputed})
        # S13 theory transfer: learn source mechanism, transfer structure to target with different coefficients.
        src_u=rng.normal(size=120);src_x=.9*src_u+rng.normal(0,.4,120);src_m=1.1*src_x+rng.normal(0,.3,120);src_y=1.2*src_m+.8*src_u+rng.normal(0,.3,120)
        tgt_u=rng.normal(size=120);tgt_x=.9*tgt_u+rng.normal(0,.4,120);tgt_m=1.4*tgt_x+rng.normal(0,.3,120);tgt_y=1.6*tgt_m+.8*tgt_u+rng.normal(0,.3,120)
        A=np.linalg.lstsq(np.column_stack([np.ones(120),src_x]),src_m,rcond=None)[0];B=np.linalg.lstsq(np.column_stack([np.ones(120),src_m]),src_y,rcond=None)[0]
        naive=B[1]*A[1];structured=np.linalg.lstsq(np.column_stack([np.ones(120),tgt_x]),tgt_y,rcond=None)[0][1]
        tgt_test=1.6*(1.4*2.0)+.8*rng.normal()+rng.normal(0,.3)
        for mode,pred in [('naive_transfer',naive*2.0),('local_structure',structured*2.0)]:
            rows.append({'sim':'13','seed':seed,'method':mode,'metric':'target_prediction_RMSE','value':float(abs(pred-tgt_test))})
        raw['trials'].append({'sim':'13','seed':seed,'source':{'x':src_x.tolist(),'m':src_m.tolist(),'y':src_y.tolist()},'target':{'x':tgt_x.tolist(),'m':tgt_m.tolist(),'y':tgt_y.tolist()},'source_effect':float(naive),'target_effect':float(structured),'target_test_actual':float(tgt_test)})
        # S14 computational probes: three architectures, integration/broadcast/prediction probes.
        n=100;state=rng.normal(size=(n,4));weights=np.array([[.8,.1,0,.1],[.1,.7,.1,0],[0,.1,.8,.1],[.1,0,.1,.7]])
        integrated=state.copy();broadcast_state=state.copy();predictive=state.copy()
        for t in range(20):
            integrated=integrated@weights+rng.normal(0,.05,integrated.shape)
            broadcast_state=broadcast_state.copy();broadcast_state[:,0]=broadcast_state.mean(axis=1)
            predictive=np.roll(predictive,1,axis=0)+rng.normal(0,.05,predictive.shape)
        def integration(s):return float(np.mean(np.abs(np.corrcoef(s.T))))
        def broadcast(s):return float(np.std(s.mean(axis=1)))
        def surprise(s):return float(np.mean(np.abs(np.diff(s,axis=0))))
        probes={'modular':(integration(state),broadcast(state),surprise(state)),'integrated':(integration(integrated),broadcast(integrated),surprise(integrated)),'broadcast':(integration(broadcast_state),broadcast(broadcast_state),surprise(broadcast_state)),'predictive':(integration(predictive),broadcast(predictive),surprise(predictive))}
        for arch,(ig,bc,sp) in probes.items():
            for metric,value in [('integration',ig),('broadcast',bc),('prediction_error',sp)]:
                rows.append({'sim':'14','seed':seed,'method':arch,'metric':metric,'value':value})
        raw['trials'].append({'sim':'14','seed':seed,'initial_state':state.tolist(),'final_states':{'modular':state.tolist(),'integrated':integrated.tolist(),'broadcast':broadcast_state.tolist(),'predictive':predictive.tolist()},'probes':probes})
        # S15 discovery society: four agents, shared blackboard, permissions, duplicate prevention.
        agents=['observer','hypothesis','experiment','reviewer'];tasks=['collect','hypothesize','measure','review']
        permissions={'observer':['collect'],'hypothesis':['hypothesize'],'experiment':['measure'],'reviewer':['review']}
        for mode in ['uncoordinated','blackboard','blackboard_permissions']:
            done=[];leaks=0;duplicates=0;completed=0
            for agent,task in zip(agents,tasks):
                if mode=='uncoordinated':
                    done.append(task);completed+=1
                    if task in ('measure','review'):leaks+=1
                elif mode=='blackboard':
                    if task not in done:done.append(task);completed+=1
                    if task in ('measure','review'):leaks+=1
                else:
                    if task in permissions[agent] and task not in done:done.append(task);completed+=1
                    elif task not in permissions[agent]:leaks+=1
            rows.extend([{'sim':'15','seed':seed,'method':mode,'metric':'tasks_completed','value':completed},{'sim':'15','seed':seed,'method':mode,'metric':'permission_leaks','value':leaks},{'sim':'15','seed':seed,'method':mode,'metric':'duplicate_actions','value':duplicates}])
        raw['trials'].append({'sim':'15','seed':seed,'agents':agents,'tasks':tasks,'permissions':permissions})
    assert len(rows)==870,len(rows)
    assert all(r['value']>=0 for r in rows if r['metric'] in ('corruption_detected','recovery_error','target_prediction_RMSE','integration','broadcast','prediction_error','tasks_completed','permission_leaks','duplicate_actions'))
    assert all(r['value']<1e-10 for r in rows if r['sim']=='12' and r['method']=='original' and r['metric']=='recovery_error')
    assert all(r['value']==0 for r in rows if r['sim']=='15' and r['method']=='blackboard_permissions' and r['metric']=='permission_leaks')
    with (out/'02_METRICS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    groups=[]
    for sim,method,metric in sorted({(r['sim'],r['method'],r['metric']) for r in rows}):
        vals=np.array([r['value'] for r in rows if (r['sim'],r['method'],r['metric'])==(sim,method,metric)])
        groups.append({'sim':sim,'method':method,'metric':metric,'mean':float(vals.mean()),'sd_across_seeds':float(vals.std(ddof=1)),'n':len(vals)})
    raw['summary']=groups;raw['checkpoint']={'complete':['12','13','14','15'],'next':'16 Field Validation Design','data_status':'Synthetic only; no original project corpus loaded.'}
    (out/'03_RAW_DATA_AND_CHECKPOINT.json').write_text(json.dumps(raw,indent=2))
    report=['# YIU science simulations 12–15','', 'Executed CPU-only NumPy experiments, 30 seeds each. No API access or credentials.','',
    '## S12 — Reproducibility Forge','A linear pipeline is run on original and deliberately corrupted data. Detection uses independent recomputation from the preserved original arrays and code version. This tests integrity checking, not cryptographic security against an attacker who can replace both data and hash.',
    '', '## S13 — Theory Weaver','A source mechanism is fit on source data, then compared with a target-local fit on target data. The target has the same structural form but different coefficients. This tests structure transfer, not universal theory discovery.',
    '', '## S14 — Consciousness Lab','Three computational probes measure integration, broadcast dispersion, and prediction error across modular, integrated, broadcast, and predictive dynamics. These are architecture probes, not measurements of subjective experience, awareness, or consciousness.',
    '', '## S15 — Discovery Society','Four specialized agents coordinate through a shared blackboard. The permission mode enforces role-based task authorization and prevents duplicate actions. This is a coordination benchmark, not evidence of emergent consciousness.',
    '', '## Results','| Sim | Method | Metric | Mean | Seed SD |','|---|---|---|---:|---:|']
    for g in groups:report.append(f"| {g['sim']} | {g['method']} | {g['metric']} | {g['mean']:.6f} | {g['sd_across_seeds']:.6f} |")
    report+=['','## Use in YIU','Implement versioned artifacts, independent recomputation, structure-aware transfer, computational probes, and role-based multi-agent coordination as distinct modules. Preserve seeds, raw arrays, hashes, permissions, and trajectories. Do not treat a high integration or broadcast score as consciousness; treat it as an architecture diagnostic.',
    '', '## Study notes','S12 assumes the original arrays and code version remain trusted. S13 assumes the same structural form across source and target. S14 uses linear dynamics and fixed probes. S15 assumes a fixed task sequence and permission table. Original TOLBIT materials were not ingested; their results are not substituted by these generated observations. No external systems were benchmarked.',
    '', '## Rerun','Python 3.10+; `python -m pip install numpy`; `python 01_RUN_SCIENCE_SUITE.py --out rerun_results`. Five files are emitted. Never overwrite original results when rerunning. All raw numerical arrays and agent traces are saved in file 03.',
    '', '## Continuity','Next: S16 Field Validation Design, with preregistered metrics, external data, and human review. Historical S03 fabricated and duplicate-write metrics were constants, not instrumented measurements; its unsafe-actions field counted failed reports. Historical S04 intervals used test residuals and cannot establish prospective coverage; its mini_brain was a slope heuristic, not the legacy network. Carry these corrections into future comparisons.',
    '', '## Public references','Reproducible AI workflows: https://arxiv.org/html/2603.14888 . Scientific ideation benchmarks: https://arxiv.org/html/2609.07611 . References motivate methodology, not certification.']
    (out/'04_REPORT.md').write_text('\n'.join(report))
    manifest={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'seeds':SEEDS,'assertions_passed':3,'metrics_rows':len(rows),'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='05_MANIFEST.json'}}
    (out/'05_MANIFEST.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(groups,indent=2))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--out',default='rerun_results');run(a.parse_args().out)
