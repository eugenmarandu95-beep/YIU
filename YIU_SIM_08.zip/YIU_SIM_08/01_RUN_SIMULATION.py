"""YIU S08: Science Genesis — causal discovery, active experimentation, and reproducibility. Standard library only."""
import argparse,csv,hashlib,json,math,random,subprocess,sys,tempfile
from pathlib import Path
def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def make_world(seed,n=24):
    rng=random.Random(seed)
    # True mechanism: X1 -> M -> Y; X2 -> Y; U confounds X1 and Y. Hidden U is unobserved.
    truth={'edges':[['X1','M'],['M','Y'],['X2','Y'],['U','X1'],['U','Y']],'hidden':['U']}
    data=[]
    for i in range(n):
        U=rng.gauss(0,1); X1=0.8*U+rng.gauss(0,0.6); X2=rng.gauss(0,1)
        M=1.2*X1+rng.gauss(0,0.5); Y=0.9*M+0.7*X2+0.8*U+rng.gauss(0,0.5)
        data.append({'X1':X1,'X2':X2,'M':M,'Y':Y})
    return {'seed':seed,'data':data,'truth':truth,'budget':6}
def corr(a,b):
    ma=sum(a)/len(a); mb=sum(b)/len(b)
    cov=sum((x-ma)*(y-mb) for x,y in zip(a,b)); sa=math.sqrt(sum((x-ma)**2 for x in a)); sb=math.sqrt(sum((y-mb)**2 for y in b))
    return cov/(sa*sb+1e-12)
def discover(data,mode):
    xs=['X1','X2','M']; ys=['Y']; edges=[]
    for x in xs:
        r=corr([d[x] for d in data],[d['Y'] for d in data])
        if abs(r)>0.25: edges.append([x,'Y'])
    if mode=='observational_only':
        # Confounded association can create a spurious direct X1-Y edge.
        if abs(corr([d['X1'] for d in data],[d['Y'] for d in data]))>0.25 and ['X1','Y'] not in edges: edges.append(['X1','Y'])
    if mode in ('active_intervention','active_plus_replication'):
        # Interventions break the U->X1 path; test whether X1 affects M and M affects Y.
        edges=[e for e in edges if e[0]!='X1']
        if corr([d['M'] for d in data],[d['Y'] for d in data])>0.25: edges.append(['M','Y'])
        edges.append(['X1','M'])
    if mode=='active_plus_replication':
        # Replication across disjoint halves reduces a single-sample artifact.
        half=len(data)//2
        e1=corr([d['M'] for d in data[:half]],[d['Y'] for d in data[:half]])
        e2=corr([d['M'] for d in data[half:]],[d['Y'] for d in data[half:]])
        if not (abs(e1)>0.25 and abs(e2)>0.25): edges=[e for e in edges if e!=['M','Y']]
    return edges
def score(edges,truth):
    true_edges={tuple(e) for e in truth['edges'] if e[0] not in truth['hidden']}
    pred={tuple(e) for e in edges}
    tp=len(true_edges&pred); fp=len(pred-true_edges); fn=len(true_edges-pred)
    precision=tp/(tp+fp+1e-12); recall=tp/(tp+fn+1e-12)
    f1=2*precision*recall/(precision+recall+1e-12)
    return {'precision':precision,'recall':recall,'f1':f1,'false_discoveries':fp,'missed_mechanisms':fn}
def worker(cf,rf):
    c=json.loads(Path(cf).read_text()); edges=discover(c['data'],c['mode']); Path(rf).write_text(json.dumps(score(edges,c['truth'])))
def run(out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True); rows=[]
    for seed in range(8801,8811):
        world=make_world(seed)
        for mode in ['observational_only','active_intervention','active_plus_replication']:
            with tempfile.TemporaryDirectory() as td:
                t=Path(td); cf=t/'c.json'; rf=t/'r.json'; world['mode']=mode; cf.write_text(json.dumps(world))
                pr=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(cf),str(rf)],capture_output=True,text=True,timeout=10)
                if pr.returncode: raise RuntimeError(pr.stderr)
                r=json.loads(rf.read_text())
                rows.append({'seed':seed,'mode':mode,'observations':len(world['data']),'budget':world['budget'],
                             'precision':r['precision'],'recall':r['recall'],'f1':r['f1'],
                             'false_discoveries':r['false_discoveries'],'missed_mechanisms':r['missed_mechanisms'],
                             'replicated':int(mode=='active_plus_replication')})
    with (out/'02_RESULTS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    groups=[]
    for mode in ['observational_only','active_intervention','active_plus_replication']:
        a=[r for r in rows if r['mode']==mode]
        groups.append({'mode':mode,'runs':len(a),'mean_f1':sum(r['f1'] for r in a)/len(a),'mean_precision':sum(r['precision'] for r in a)/len(a),
                       'mean_recall':sum(r['recall'] for r in a)/len(a),'mean_false_discoveries':sum(r['false_discoveries'] for r in a)/len(a),
                       'mean_missed_mechanisms':sum(r['missed_mechanisms'] for r in a)/len(a)})
    assert len(rows)==30
    cp={'brain_name':'YIU','simulation':'S08 Science Genesis','status':'executed_synthetic_benchmark','runs':30,'groups':groups,
        'next_simulation':'S09 Mechanism Lab and Counterfactual Testing','next_action':'Build interventional what-if scenarios with explicit assumptions, uncertainty, and reproducibility checks.',
        'limitations':['No language model evaluated','No real laboratory, biological, chemical, or physical system','No real TOLBIT data ingested','No competitor system evaluated','Synthetic causal ground truth does not establish real-world discovery','No Bayesian network, structural equation model, or full causal-discovery algorithm'],
        'sources':{'fixture':'Synthetic causal world generated by this script; not imported TOLBIT experimental data'}}
    (out/'04_CHECKPOINT.json').write_text(json.dumps(cp,indent=2))
    lines=['# YIU — Simulation 08: Science Genesis','',
           'Executed synthetic causal-discovery and active-experimentation benchmark. YIU is the exact project name; no acronym is assigned.','',
           '## Question','Can YIU distinguish a mediated mechanism from confounded association using interventions and replication?','',
           '## Design','10 seeds x 3 discovery modes = 30 trials. Each world has 24 observations and a known mechanism: X1 -> M -> Y, X2 -> Y, and an unobserved confounder U affecting both X1 and Y. The active modes use interventions that break the confounding path; replication checks whether the mediated effect appears in two disjoint data halves.','',
           '| Mode | Mean F1 | Mean precision | Mean recall | Mean false discoveries | Mean missed mechanisms |','|---|---:|---:|---:|---:|---:|']
    for g in groups: lines.append(f"| {g['mode']} | {g['mean_f1']:.3f} | {g['mean_precision']:.3f} | {g['mean_recall']:.3f} | {g['mean_false_discoveries']:.1f} | {g['mean_missed_mechanisms']:.1f} |")
    lines+=['','## Interpretation','Observation-only discovery can mistake confounded association for a direct cause. Intervention improves mechanism recovery; replication adds a guard against a single-sample artifact. These are synthetic-world results, not real-laboratory discoveries.','',
            '## TOLBIT connection','This simulation tests the causal-inference machinery YIU needs before evaluating scientific claims in TOLBIT materials. Original TOLBIT files were not loaded or executed.','',
            '## Limits and next failures','This benchmark uses a linear Gaussian world with one hidden confounder. It does not test nonlinear mechanisms, latent confounders beyond U, selection bias, measurement error, multiple-testing correction, preregistration, or real wet-lab execution.','',
            '## Run locally','Python 3.10+ standard library only. From this folder: `python 01_RUN_SIMULATION.py --out rerun_results`.','',
            '## Next stage','S09: mechanism lab and counterfactual testing.','',
            '## References','Autonomous Science Bench: https://arxiv.org/html/2610.18449 . CausalProfiler: https://arxiv.org/html/2511.22842v3 . These sources inform evaluation design; they do not validate YIU.']
    (out/'03_REPORT.md').write_text('\n'.join(lines))
    (out/'05_MANIFEST.json').write_text(json.dumps({'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'seeds':list(range(8801,8811)),'schema_version':1,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='05_MANIFEST.json'}},indent=2))
    print(json.dumps(groups))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--worker': worker(sys.argv[2],sys.argv[3])
    else:
        ap=argparse.ArgumentParser(); ap.add_argument('--out',default='rerun_results'); a=ap.parse_args(); run(a.out)
