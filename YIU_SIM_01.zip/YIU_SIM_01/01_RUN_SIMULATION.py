"""YIU S01: state recovery benchmark. Standard library only. Synthetic fixtures."""
import argparse, csv, hashlib, json, random, subprocess, sys, tempfile
from pathlib import Path

def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def initial():
    return {'step':0,'balance':0,'task':'audit_legacy_memory_claim','corrections':{},'evidence':[],'history_hash':'start'}

def event_tape(seed,n=96):
    rng=random.Random(seed)
    tape=[]
    for i in range(n):
        tape.append({'step':i+1,'delta':rng.randint(-9,12),'observation':rng.choice(['stable','novel','uncertain']),
                     'correction': 'v5_measured_snapshot_similarity_not_trained_recall' if i==19 else None})
    return tape

def advance(s,e):
    assert e['step']==s['step']+1
    s=json.loads(json.dumps(s))
    s['step']=e['step']; s['balance']+=e['delta']
    if e['correction']: s['corrections']['legacy_v5']=e['correction']
    if e['step']%11==0: s['evidence'].append({'step':e['step'],'status':e['observation']})
    s['history_hash']=digest([s['history_hash'],e])
    return s

def save_snapshot(path,state):
    payload={'schema':1,'state':state,'checksum':digest(state)}
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(payload)); tmp.replace(path)

def load_latest(directory):
    rejected=0
    for p in sorted(directory.glob('snapshot_*.json'),reverse=True):
        try:
            payload=json.loads(p.read_text())
            if payload['schema']!=1 or digest(payload['state'])!=payload['checksum']: raise ValueError('integrity')
            return payload['state'],rejected
        except (ValueError,KeyError,TypeError): rejected+=1
    return initial(),rejected

def worker(case_file,result_file):
    c=json.loads(Path(case_file).read_text()); tape=c['tape']; mode=c['mode']
    state,rejected=(initial(),0) if mode=='volatile' else load_latest(Path(c['snapshots']))
    restored_step=state['step']; replayed=0
    if mode=='snapshot_replay':
        for e in tape[restored_step:c['interrupt']]: state=advance(state,e); replayed+=1
    skipped=c['interrupt']-state['step']
    # Snapshot-only deliberately misses events between last durable snapshot and crash.
    # Process subsequent events without claiming that missing history was recovered.
    for e in tape[c['interrupt']:]:
        if e['step']!=state['step']+1: state['step']=e['step']-1
        state=advance(state,e)
    Path(result_file).write_text(json.dumps({'state':state,'restored_step':restored_step,'replayed':replayed,'skipped':skipped,'rejected':rejected}))

def run(out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True); rows=[]
    for seed in range(8101,8111):
        tape=event_tape(seed); oracle=initial()
        for e in tape: oracle=advance(oracle,e)
        for scenario in ['restart','corrupt_latest','partial_write']:
            for mode in ['volatile','snapshot_only','snapshot_replay']:
                with tempfile.TemporaryDirectory() as td:
                    d=Path(td); snaps=d/'snapshots'; snaps.mkdir(); state=initial()
                    for e in tape[:43]:
                        state=advance(state,e)
                        if state['step']%7==0: save_snapshot(snaps/f"snapshot_{state['step']:04d}.json",state)
                    if scenario=='corrupt_latest':
                        # Valid JSON with altered state: checksum detects inconsistency.
                        latest=snaps/'snapshot_0042.json'; p=json.loads(latest.read_text()); p['state']['balance']+=1000; latest.write_text(json.dumps(p))
                    if scenario=='partial_write': (snaps/'snapshot_0043.tmp').write_text('{incomplete')
                    case={'tape':tape,'mode':mode,'snapshots':str(snaps),'interrupt':43}
                    cp=d/'case.json'; rp=d/'result.json'; cp.write_text(json.dumps(case))
                    proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(cp),str(rp)],capture_output=True,text=True,timeout=10)
                    if proc.returncode: raise RuntimeError(proc.stderr)
                    r=json.loads(rp.read_text()); final=r['state']
                    rows.append({'seed':seed,'scenario':scenario,'mode':mode,'steps':96,'interrupted_after':43,
                                 'restored_step':r['restored_step'],'replayed_events':r['replayed'],'lost_events':r['skipped'],
                                 'rejected_snapshots':r['rejected'],'exact_state_match':int(final==oracle),
                                 'correction_retained':int(final['corrections']==oracle['corrections']),
                                 'balance_absolute_error':abs(final['balance']-oracle['balance']),
                                 'oracle_hash':digest(oracle),'recovered_hash':digest(final)})
    with (out/'02_RESULTS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    groups=[]
    for scenario in ['restart','corrupt_latest','partial_write']:
        for mode in ['volatile','snapshot_only','snapshot_replay']:
            a=[r for r in rows if r['scenario']==scenario and r['mode']==mode]
            groups.append({'scenario':scenario,'mode':mode,'runs':len(a),'exact_matches':sum(r['exact_state_match'] for r in a),
                           'corrections_retained':sum(r['correction_retained'] for r in a),'mean_lost_events':sum(r['lost_events'] for r in a)/len(a)})
    assert len(rows)==90
    assert all(r['exact_state_match']==1 for r in rows if r['mode']=='snapshot_replay')
    assert all(r['exact_state_match']==0 for r in rows if r['mode']!='snapshot_replay')
    checkpoint={'brain_name':'YIU','simulation':'S01 State Continuity','status':'executed_synthetic_benchmark',
                'runs':90,'groups':groups,'next_simulation':'S02 Memory Correction and Evidence Conflict',
                'next_action':'Build held-out claim/correction tasks from original TOLBIT passages; no separate research brain.',
                'limitations':['No language model evaluated','No biological or subjective-consciousness inference','No competitors tested','No external side effects','Single-interruption deterministic replay with trusted complete event tape','No hardware power-loss durability certification'],
                'sources':{'fixture':'Conversation correction: v5 snapshot similarity is not trained memory; manually encoded, not an imported dataset'}}
    (out/'04_CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2))
    lines=['# YIU — Simulation 01: State Continuity','',
           'Executed synthetic recovery benchmark. YIU is the exact project name; no acronym is assigned.',
           '', '## Question','Can an interrupted state machine recover its exact uninterrupted state, including a previously recorded correction?',
           '', '## Design','10 seeds x 3 restart scenarios x 3 storage modes = 90 trials. Each trial has 96 events; interruption occurs after event 43; checkpoints every 7 events. Recovery runs in a fresh Python subprocess. The controller intentionally supplies a trusted complete event tape.',
           'Scenarios: normal restart; checksum-invalid latest snapshot with fallback; incomplete temporary write ignored. Controls: volatile state and snapshot-only. Candidate: snapshot plus event replay.',
           '', '| Scenario | Mode | Exact recovery | Lost events (mean) |','|---|---|---:|---:|']
    for g in groups: lines.append(f"| {g['scenario']} | {g['mode']} | {g['exact_matches']}/{g['runs']} | {g['mean_lost_events']:.1f} |")
    lines+=['','## Interpretation','Replay recovery passes this deliberately bounded engineering test. Snapshots alone lose events after the last checkpoint; volatile state loses all pre-interruption history. This is a recovery implementation result, not evidence of intelligence, learning, consciousness, or superiority over commercial systems.',
            '', '## TOLBIT connection','The retained correction is manually transcribed from this conversation: v5 measured snapshot similarity, not trained recall. Original TOLBIT files were not loaded in this benchmark. This first simulation tests the infrastructure needed to preserve their future corrections, not their scientific validity.',
            '', '## Limits and next failures','Checksums detect accidental changes, not a malicious actor able to replace both state and hash. Temporary-file rename is not proof of power-loss durability. Test event-log corruption, unavailable tape, schema migration, model/RNG state, deleted data, and exactly-once external actions separately. This implementation has no external actions and does not solve duplicate financial postings.',
            '', '## Run locally','Python 3.10+ standard library only. From this folder: `python 01_RUN_SIMULATION.py --out rerun_results`. Rerun output is deliberately separate from the bundled results.',
            '', '## Next stage','S02: evidence-tagged memory and correction conflicts. Research objectives stay in YIU core. Compare systems on identical tasks/budgets before making competitor claims.',
            '', '## Reference','Python subprocess documentation: https://docs.python.org/3/library/subprocess.html . This source explains process execution, not the scientific validity of the study.']
    (out/'03_REPORT.md').write_text('\n'.join(lines))
    manifest={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'seeds':list(range(8101,8111)),
              'schema_version':1,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='05_MANIFEST.json'}}
    (out/'05_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(groups))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--worker': worker(sys.argv[2],sys.argv[3])
    else:
        parser=argparse.ArgumentParser(); parser.add_argument('--out',default='rerun_results'); args=parser.parse_args(); run(args.out)
