"""YIU scientific pilot 09-11. Python 3.10+, numpy. No API or LLM required."""
import argparse,csv,hashlib,json,platform,sys
from pathlib import Path
import numpy as np
SEEDS=list(range(8901,8931))
def fit(x,y): return np.linalg.lstsq(x,y,rcond=None)[0]
def features(x,k):
    if k=='linear':return np.column_stack([np.ones(len(x)),x])
    if k=='quadratic':return np.column_stack([np.ones(len(x)),x,x*x])
    if k=='sinusoidal':return np.column_stack([np.ones(len(x)),x,np.sin(2*x)])
    raise ValueError(k)
def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rows=[]; raw={'config':{'seeds':SEEDS,'S09':'200 observational + 200 randomized training; 100 factual test units; intervention X=1.5','S10':'100 training, 40 selection, 100 untouched test; Gaussian noise sd=0.5','S11':'12 experiments, noise sd=0.6, 61 possible inputs, uniform prior; variance acquisition is a disagreement proxy, not exact information gain'},'trials':[]}
    for seed in SEEDS:
        rng=np.random.default_rng(seed)
        a,b,c=rng.uniform(.6,1.5,3); conf=rng.uniform(.6,1.2)
        u=rng.normal(size=200);x=conf*u+rng.normal(0,.5,200);m=a*x+rng.normal(0,.3,200);y=b*m+c*u+rng.normal(0,.3,200)
        # A real simulated do(X): X is randomized independently of U.
        ui=rng.normal(size=200);xi=rng.normal(0,1.5,200);mi=a*xi+rng.normal(0,.3,200);yi=b*mi+c*ui+rng.normal(0,.3,200)
        ut=rng.normal(size=100);xt=conf*ut+rng.normal(0,.5,100);em=rng.normal(0,.3,100);ey=rng.normal(0,.3,100)
        factual=b*(a*xt+em)+c*ut+ey
        # Paired unit-level counterfactual keeps U and exogenous noises fixed.
        counterfactual=b*(a*1.5+em)+c*ut+ey
        estimates={'observational_OLS':fit(np.column_stack([np.ones(200),x]),y)[1], 'randomized_OLS':fit(np.column_stack([np.ones(200),xi]),yi)[1], 'known_mechanism_reference':a*b}
        logs=[]
        for mode,effect in estimates.items():
            pred=factual+effect*(1.5-xt);err=float(np.sqrt(np.mean((pred-counterfactual)**2)))
            rows.append({'sim':'09','seed':seed,'method':mode,'metric':'counterfactual_RMSE','value':err})
            logs.append({'method':mode,'effect_estimate':float(effect),'predictions':pred.tolist()})
        raw['trials'].append({'sim':'09','seed':seed,'parameters':[a,b,c,conf],'observational':np.column_stack([x,m,y]).tolist(),'randomized':np.column_stack([xi,mi,yi]).tolist(),'test_factual':np.column_stack([xt,factual]).tolist(),'test_counterfactual':counterfactual.tolist(),'estimates':logs})
        rng=np.random.default_rng(seed+10000);kinds=['linear','quadratic','sinusoidal'];truth=kinds[(seed-SEEDS[0])%3]
        coef=rng.uniform(.5,1.5,size=features(np.array([0.]),truth).shape[1]);coef[0]=rng.uniform(-1,1)
        sets=[]
        for n in [100,40,100]:
            xx=rng.uniform(-2,2,n);yy=features(xx,truth)@coef+rng.normal(0,.5,n);sets.append((xx,yy))
        (tr,ty),(va,vy),(te,tey)=sets
        candidates={k:fit(features(tr,k),ty) for k in kinds}
        val={k:float(np.mean((features(va,k)@v-vy)**2)) for k,v in candidates.items()}
        chosen=min(val,key=val.get)
        for mode,k in [('fixed_linear','linear'),('validation_ranked',chosen)]:
            mse=float(np.mean((features(te,k)@candidates[k]-tey)**2))
            rows.extend([{'sim':'10','seed':seed,'method':mode,'metric':'test_MSE','value':mse},{'sim':'10','seed':seed,'method':mode,'metric':'correct_family','value':float(k==truth)}])
        raw['trials'].append({'sim':'10','seed':seed,'truth_family':truth,'coefficients':coef.tolist(),'data':[{'x':xx.tolist(),'y':yy.tolist()} for xx,yy in sets],'validation_MSE':val,'selected_family':chosen,'fitted_coefficients':{k:v.tolist() for k,v in candidates.items()}})
        # Separate closed-world sequential experiment benchmark with fixed candidate mechanisms.
        rng=np.random.default_rng(seed+20000);grid=np.linspace(-2,2,61)
        functions=np.array([.8*grid, .8*grid+.65*grid**2, .8*grid+1.2*np.sin(2*grid)])
        hidden=(seed-SEEDS[0])%3;sd=.6
        # Same potential measurement noise at each input for all policies; query without replacement.
        noise=rng.normal(0,sd,len(grid));logs=[]
        for mode in ['random_design','space_filling','posterior_disagreement']:
            policy_rng=np.random.default_rng(seed+30000);p=np.ones(3)/3;available=list(range(len(grid)));trace=[]
            fixed=list(np.linspace(0,60,12).round().astype(int))
            for step in range(12):
                if mode=='random_design':i=int(policy_rng.choice(available))
                elif mode=='space_filling':i=fixed[step]
                else:
                    avg=p@functions;disagreement=p@(functions**2)-avg**2
                    i=max(available,key=lambda j:float(disagreement[j]))
                observation=float(functions[hidden,i]+noise[i]);available.remove(i)
                logp=np.log(np.maximum(p,1e-300))-.5*((observation-functions[:,i])/sd)**2
                p=np.exp(logp-logp.max());p/=p.sum()
                trace.append({'step':step+1,'x':float(grid[i]),'observation':observation,'posterior':p.tolist()})
            # Held-out continuous inputs not used as experiments, noiseless target measures model learning.
            hold=np.linspace(-1.98,1.98,200);fhold=np.array([.8*hold,.8*hold+.65*hold**2,.8*hold+1.2*np.sin(2*hold)])
            mse=float(np.mean((p@fhold-fhold[hidden])**2))
            entropy=float(-np.sum(p*np.log(np.maximum(p,1e-300))))
            for metric,value in [('heldout_function_MSE',mse),('correct_family',float(int(np.argmax(p))==hidden)),('posterior_entropy',entropy)]:
                rows.append({'sim':'11','seed':seed,'method':mode,'metric':metric,'value':value})
            logs.append({'method':mode,'trace':trace})
        raw['trials'].append({'sim':'11','seed':seed,'truth_index':hidden,'grid':grid.tolist(),'potential_measurement_noise':noise.tolist(),'campaigns':logs})
    assert len(rows)==480,len(rows)
    assert all(np.isfinite(r['value']) for r in rows)
    assert all(r['value']<1e-10 for r in rows if r['sim']=='09' and r['method']=='known_mechanism_reference')
    assert all(len(c['trace'])==12 and len({t['x'] for t in c['trace']})==12 for t in raw['trials'] if t['sim']=='11' for c in t['campaigns'])
    with (out/'02_METRICS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    groups=[]
    for sim,method,metric in sorted({(r['sim'],r['method'],r['metric']) for r in rows}):
        vals=np.array([r['value'] for r in rows if (r['sim'],r['method'],r['metric'])==(sim,method,metric)])
        groups.append({'sim':sim,'method':method,'metric':metric,'mean':float(vals.mean()),'sd_across_seeds':float(vals.std(ddof=1)),'n':len(vals)})
    raw['summary']=groups;raw['checkpoint']={'complete':['09','10','11'],'next':'12 Reproducibility Forge','data_status':'Synthetic only; no original project corpus loaded.'}
    (out/'03_RAW_DATA_AND_CHECKPOINT.json').write_text(json.dumps(raw,indent=2))
    report=['# YIU science simulations 09–11','', 'Executed CPU-only NumPy experiments, 30 seeds each. No API access or credentials.','',
    '## S09 — Mechanism Lab','Observational and genuinely randomized simulated training datasets estimate the total effect of X through M on Y under hidden confounding. Unit-level counterfactuals retain the same exogenous disturbances. A known-mechanism reference is explicitly labeled and is not a learned competitor.',
    'Correction to S08: its active_intervention branch hard-coded X1->M and removed X1->Y without collecting interventional data; its reported improvement was not demonstrated intervention learning. S09 replaces that shortcut with randomized samples and fitted effect estimates.',
    '', '## S10 — Hypothesis Forge','Fit linear, quadratic, and sinusoidal candidates on training data; rank on a separate selection set; evaluate on untouched test data. Truth families are balanced across seeds. This is finite candidate selection, not open-ended hypothesis invention.',
    '', '## S11 — Experiment Designer','Compare random, space-filling, and posterior-disagreement selection with exactly 12 measurements per campaign. All policies share candidate functions, noise model, prior, input options, and potential measurement noise. The policy never sees the truth index. Truth is used only by the measurement simulator and evaluator. Evaluate posterior prediction on a separate dense input grid. Disagreement is an acquisition heuristic, not exact information gain.',
    '', '## Results','| Sim | Method | Metric | Mean | Seed SD |','|---|---|---|---:|---:|']
    for g in groups:report.append(f"| {g['sim']} | {g['method']} | {g['metric']} | {g['mean']:.6f} | {g['sd_across_seeds']:.6f} |")
    report+=['','## Use in YIU','Implement causal effect estimation, data-separated model ranking, and a budget-enforced sequential experiment API as distinct modules. Preserve seeds, samples, query trajectories and model versions. Do not equate variance acquisition with an intelligent scientist; assess on broader held-out mechanisms before choosing it as a default.',
    '', '## Study notes','These are linear/confounded and small closed-family synthetic worlds. S09 assumes a constant total effect and uses factual outcome plus estimated effect for unit counterfactual prediction. S11 assumes the true function is among three known candidates and the noise scale is known. Original TOLBIT materials were not ingested; their results are not substituted by these generated observations. No external systems were benchmarked.',
    '', '## Rerun','Python 3.10+; `python -m pip install numpy`; `python 01_RUN_SCIENCE_SUITE.py --out rerun_results`. Five files are emitted. Never overwrite original results when rerunning. Model selection settings are fixed in the script; no test-set tuning is performed. All raw numerical inputs and sequential measurements are saved in file 03.',
    '', '## Continuity','Next: S12 Reproducibility Forge, with deliberate data, code, and result corruption plus independent recomputation. Historical S03 fabricated and duplicate-write metrics were constants, not instrumented measurements; its unsafe-actions field counted failed reports. Historical S04 intervals used test residuals and cannot establish prospective coverage; its mini_brain was a slope heuristic, not the legacy network. Carry these corrections into future comparisons.',
    '', '## Public references','Causal benchmark design: https://arxiv.org/html/2511.22842v2 . Budgeted science campaigns: https://arxiv.org/abs/2610.18449 . References motivate methodology, not certification.']
    (out/'04_REPORT.md').write_text('\n'.join(report))
    manifest={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'seeds':SEEDS,'assertions_passed':4,'metrics_rows':len(rows),'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='05_MANIFEST.json'}}
    (out/'05_MANIFEST.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(groups,indent=2))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--out',default='rerun_results');run(a.parse_args().out)
